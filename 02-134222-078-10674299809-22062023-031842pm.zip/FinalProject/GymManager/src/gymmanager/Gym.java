
package gymmanager;


public class Gym {

    public static void main(String[] args) {
        SelectionPane p1=new SelectionPane();
        p1.show();
      
    
    }
}

