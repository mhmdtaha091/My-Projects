package gymmanager;

 import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class Trainer extends User{
    
    public boolean value = false;
    public   String staffId;

    private static final String DATABASE_URL = "jdbc:ucanaccess://Gym.accdb";

    public Trainer(String staffId,String name, int age, int contact) {
        super(name, age, contact);
        this.staffId=staffId;
    }

    public Trainer(String staffId, String name, int age, int contact, String password) {
        super(name, age, contact, password);
        this.staffId=staffId;
    }

    Trainer() {
    }
    
    public String getStaffId(){
        return staffId;
    }
   
    private static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DATABASE_URL);
    }

    
   

    
    public void addTrainer() {
        value=false;
        try (Connection connection = getConnection();
            PreparedStatement statement = connection.prepareStatement("INSERT INTO Trainers(StaffId, Name, Age, Contact, Password )  VALUES (?, ?, ?, ?, ?)")) {
            statement.setString(1,  staffId);
            statement.setString(2, getName());
            statement.setInt(3, getAge());
            statement.setInt(4, getContact());
            statement.setString(5, getPassword());
            statement.executeUpdate();
            value=true;
        } catch (SQLException e) {
            value=false;
            System.err.println("Error saving trainer details to database: " + e.getMessage());
        }
    }

    
    public static List<Trainer> getAllTrainers() {
       
        List<Trainer> trainers = new ArrayList<>();
        try (Connection connection = getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("SELECT * FROM Trainers")) {
            
            while (resultSet.next()) {
               
                String staffId2 = resultSet.getString("StaffId");
                String name = resultSet.getString("Name");
                int age = resultSet.getInt("Age");
                int contact = resultSet.getInt("Contact");
                String pass = resultSet.getString("Password");
                trainers.add(new Trainer(staffId2, name, age, contact,pass));
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving Trainers from database: " + e.getMessage());
        }
        return trainers;
    }

    
    public Trainer searchTrainerById(String staffId1) {
        
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement("SELECT * FROM Trainers WHERE StaffId = ?")) {
            statement.setString(1, staffId1);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                int contact = resultSet.getInt("Contact");
                int age = resultSet.getInt("Age");
                String name = resultSet.getString("Name");
                return new Trainer(staffId1, name, age, contact);
            }
        } catch (SQLException e) {
            System.err.println("Error searching for Trainer in the database: " + e.getMessage());
        }
        return null;
    }
   
    public void deleteTrainerInfo(String tId) {
       value = false;
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement("DELETE FROM Trainers WHERE staffId = ?")) {
           statement.setString(1, tId);
            statement.executeUpdate();
            value=true;
        } catch (SQLException e) {
            value = false;
            System.err.println("Error deleting trainer details from the database: " + e.getMessage());
        }
    }
    
    public List<Trainer> readTrainersFromDatabase() {
       
        List<Trainer> trainers = new ArrayList<>();
        try (Connection connection = getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("SELECT * FROM Trainers")) {
            while (resultSet.next()) {
                String staffId1 = resultSet.getString("StaffId");
                String name = resultSet.getString("name");
                int contact = resultSet.getInt("Contact");
                int age = resultSet.getInt("age");
                
                trainers.add(new Trainer(staffId1, name, age, contact));
            }
        } catch (SQLException e) {
            System.err.println("Error reading trainers from the database: " + e.getMessage());
        }
        return trainers;
    }

    
    public static void displayAllTrainers() {
        List<Trainer> trainers = getAllTrainers();
        for (Trainer trainer : trainers) {
            System.out.println("Staff Id: " + trainer.getStaffId());
            System.out.println("Name: " + trainer.getName());
            System.out.println("Contact Number: " + trainer.getContact());
            System.out.println("Age: " + trainer.getAge());    
            System.out.println("-----------------------------");
        }
    }

    @Override
    public void login(String id, String pass) {
       try {
           value=false;
            String DbBlock="jdbc:ucanaccess://Gym.accdb";
            Connection con =DriverManager.getConnection(DbBlock);
            PreparedStatement prepstate=con.prepareStatement("SELECT * FROM Trainers WHERE StaffId='"+id+"'AND Password = '"+pass+"'");
                    ResultSet rset = prepstate.executeQuery();
                    if(rset.next()){
                        
                    value  =true;
                    }
                    prepstate.close();
                    con.close();
                   
                    } catch (SQLException ex) {
                        value=false;
            System.out.println(ex);
        }
            }
    }
