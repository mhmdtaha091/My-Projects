package gymmanager;

import java.util.Random;
import java.util.UUID;

abstract public class User {
    
    private String name;
    private int age;
    private int contact;
    private String password;
   
   public User(){
       
   }
    
    public String getName(){
        return name;
    }
    public int getAge(){
        return age;
    }
    public int getContact(){
        return contact;
    }
    public String getPassword(){
        return password;
    }
   
    
    public void setName(String name){
        this.name=name;
    }
    public void setAge(int age){
        this.age=age;
    }
    public void setContact(int contact){
        this.contact=contact;
    }
    public void setPassword(String password){
        this.password=password;
    }
    
    public User(String name, int age, int contact){
        this.name=name;
        this.age=age;
        this.contact=contact;
        
    }
    public User(String name, int age, int contact, String password){
        this.name=name;
        this.age=age;
        this.contact=contact;
        this.password=password;
    }
    
    abstract public void login(String id, String password);
    
    public static int generateRandomId() {
         Random random = new Random();
        
        // Generate a random integer
        int randomNumber = random.nextInt(1000)+1;
        System.out.println("Random Integer: " + randomNumber);
    return randomNumber;
    }
    
}
