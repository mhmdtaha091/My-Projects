
package gymmanager;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class Member extends User {
    
    public String membershipType;
    public String memberId;
    public String trainerId;
    public boolean membershipStatus;
    boolean value = false;
    

    private static final String DATABASE_URL = "jdbc:ucanaccess://Gym.accdb";

    public Member(){
        
    }
   
    private static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DATABASE_URL);
    }

    public Member(String memberId, String name, int age, int contact,String trainerId, String membershipType, boolean membershipStatus) {
        super(name, age, contact);
        this.membershipType=membershipType;
        this.membershipStatus=membershipStatus;
        this.trainerId=trainerId;
        this.memberId=memberId;
    }
    
    public Member(String memberId, String name, int age, int contact, String membershipType, boolean membershipStatus, String password) {
        super(name, age, contact, password);
        this.memberId=memberId;
        this.membershipType=membershipType;
        this.membershipStatus=membershipStatus;
    }
    public Member(String memberId, String name, int age, int contact, String trainerId, String membershipType, boolean membershipStatus, String password) {
        super(name, age, contact, password);
        this.memberId=memberId;
        this.membershipType=membershipType;
        this.membershipStatus=membershipStatus;
        this.trainerId=trainerId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }
    
    public String getMemberId(){
        return memberId;
    }
    public String getMembershipType(){
        return membershipType;
    }
    public Boolean getMembershipStatus(){
        return membershipStatus;
    }
    public String getTrainerId(){
        return trainerId;
    }
    
    
    public void addMember(Member m1) {
        value=false;
    try (Connection connection = getConnection();
         PreparedStatement statement = connection.prepareStatement("INSERT INTO Members (MemberId,Name, Age, Contact, TrainerId, Membership, Status, Password ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)")) {
//        System.out.println("gggggggg");
          statement.setString(1, m1.memberId);
//        System.out.println(m1.memberId);
          statement.setString(2, m1.getName());
//        System.out.println(m1.getName());
          statement.setInt(3, m1.getAge());
//        System.out.println(m1.getAge());
         statement.setInt(4, m1.getContact());
//        System.out.println(m1.getContact());
          statement.setString(5, m1.trainerId); 
//        System.out.println(m1.trainerId);
          statement.setString(6,m1.membershipType);
//        System.out.println(m1.membershipType);
          statement.setBoolean(7,m1.membershipStatus);
//        System.out.println(m1.membershipStatus);
        statement.setString(8, m1.getPassword());
//        System.out.println(m1.getPassword());
        statement.executeUpdate();
        value = true;
    } catch (SQLException e) {
        value=false;
        System.err.println("Error saving member details to database: " + e.getMessage());
    }
}

    
    public static List<Member> getAllMembers() {
        
        List<Member> members = new ArrayList<>();
        try (Connection connection = getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("SELECT * FROM Members")) {
            while (resultSet.next()) {
                String memberId = resultSet.getString("MemberId");
                String name = resultSet.getString("Name");
                int age = resultSet.getInt("Age");
                int contact = resultSet.getInt("Contact");
                String trainerId = resultSet.getString("TrainerId");
                String membershipType = resultSet.getString("Membership");
                boolean membershipStatus= resultSet.getBoolean("Status");
                String password = resultSet.getString("Password");
                members.add(new Member(memberId, name, age, contact, trainerId, membershipType, membershipStatus, password));
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving members from database: " + e.getMessage());
        }
        return members;
    }

   
    public Member searchMemberById(String memberId) {
        
        try {
            Connection connection = getConnection();
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM Members WHERE memberId = 1"); 
           
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                String name = resultSet.getString("Name");
                int age = resultSet.getInt("Age");
                int contact = resultSet.getInt("Contact");
                String trainerId = resultSet.getString("TrainerId");
                String membershipType = resultSet.getString("Membership");
                boolean membershipStatus= resultSet.getBoolean("Status");
                statement.close();
                connection.close();
                
                return new Member(memberId, name, age, contact, trainerId, membershipType, membershipStatus);
            }
        } catch (SQLException e) {
            System.err.println("Error searching for member in the database: " + e.getMessage());
        }
        
        
        
        return null;
        
    }

    
    public static void updateMemberInfo(Member member, String name, int age, int contact,  String membershipType, boolean membershipStatus) {

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement("UPDATE Members SET Age = ?, Contact = ?, Membership = ?, Status = ? WHERE MemberId = ?")) {
            statement.setInt(1, age);
            statement.setInt(2, contact);
            statement.setString(3, membershipType);
            statement.setBoolean(4, membershipStatus);
            statement.setString(5, member.getMemberId());
            statement.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error updating member details in the database: " + e.getMessage());
        }
    }

    
    public void deleteMember(String mId) {
     
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement("DELETE FROM Members WHERE MemberId= ?")) {
            statement.setString(1, mId);
            statement.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error deleting member details from the database: " + e.getMessage());
        }
    }

    
    public static void displayAllMembers() {
        List<Member> members = getAllMembers();
        for (Member member : members) {
            System.out.println("Member Id: " + member.getMemberId());
            System.out.println("Name: " + member.getName());
            System.out.println("Age: " + member.getAge());
            System.out.println("Contact: " + member.getContact());
            System.out.println("Trainer Id: " + member.getTrainerId());
            System.out.println("Membership Type: " + member.getMembershipType());
            System.out.println("Membership Status: " + member.getMembershipStatus());
            System.out.println("-----------------------------");
        }
    }

    @Override
    public void login(String id, String pass) {
        try {
            String DbBlock="jdbc:ucanaccess://Gym.accdb";
            Connection con =DriverManager.getConnection(DbBlock);
            PreparedStatement prepstate=con.prepareStatement("SELECT * FROM Members WHERE MemberId='"+id+"'AND Password = '"+pass+"'");
                    ResultSet rset = prepstate.executeQuery();
                    prepstate.close();
                    if(rset.next()){
                        
                    value  =true;
                    }
                    con.close();
                   
                    } catch (SQLException ex) {
            System.out.println(ex);
        }
         if(value==true){
            JOptionPane.showMessageDialog(null, "Login succesful", "congrats", JOptionPane.INFORMATION_MESSAGE);
        }
        else{
            JOptionPane.showMessageDialog(null, "error while logging in", "failed", JOptionPane.ERROR_MESSAGE);
         }
    }
    

    
}