package gymmanager;

import java.util.Scanner;

public class Admin {
    private String password;

    public Admin(String password) {
        this.password = password;
    }

    public boolean login(String enteredPassword) {
        return password.equals(enteredPassword);
    }

    public void addEquipment() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter equipment ID:");
        String equipmentID = scanner.nextLine();
        System.out.println("Enter equipment name:");
        String name = scanner.nextLine();
        System.out.println("Enter equipment description:");
        String description = scanner.nextLine();
        System.out.println("Enter equipment quantity:");
        int quantity = scanner.nextInt();
        scanner.nextLine(); 
        System.out.println("Enter equipment condition:");
        String condition = scanner.nextLine();

        Equipment equipment = new Equipment(equipmentID, name, description, quantity, condition);
        equipment.addEquipment();
    }

    public static void main(String[] args) {
        String adminPassword = "admin123";
        Admin admin = new Admin(adminPassword);

        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter admin password:");
        String enteredPassword = scanner.nextLine();

        if (admin.login(enteredPassword)) {
            System.out.println("Login successful!");
            admin.addEquipment();
        } else {
            System.out.println("Invalid password. Login failed.");
        }
    }
}