package gymmanager;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Equipment {
    private String equipmentID;
    private String name;
    private String description;
    private int quantity;
    private String condition;
    private boolean availability;

    public Equipment(String equipmentID, String name, String description, int quantity, String condition) {
        this.equipmentID = equipmentID;
        this.name = name;
        this.description = description;
        this.quantity = quantity;
        this.condition = condition;
        this.availability = true; // Assume equipment is available by default
    }

    

    public String getEquipmentID() {
        return equipmentID;
    }

    public void setEquipmentID(String equipmentID) {
        this.equipmentID = equipmentID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public boolean isAvailability() {
        return availability;
    }

    public void setAvailability(boolean availability) {
        this.availability = availability;
    }


    public void increaseQuantity(int quantityToAdd) {
        this.quantity += quantityToAdd;
    }

    public void decreaseQuantity(int quantityToSubtract) {
        this.quantity -= quantityToSubtract;
    }

    public void addEquipment() {
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/your_database_name", "your_username", "your_password");
             PreparedStatement statement = connection.prepareStatement("INSERT INTO Equipment (equipmentID, name, description, quantity, condition, availability) VALUES (?, ?, ?, ?, ?, ?)")) {
            statement.setString(1, equipmentID);
            statement.setString(2, name);
            statement.setString(3, description);
            statement.setInt(4, quantity);
            statement.setString(5, condition);
            statement.setBoolean(6, availability);
            statement.executeUpdate();
            System.out.println("Equipment added successfully.");
        } catch (SQLException e) {
            System.err.println("Error adding equipment to the database: " + e.getMessage());
        }
    }
     public static List<Equipment> getAllEquipment() {
        
        List<Equipment> equipmentList = new ArrayList<>();
        
        equipmentList.add(new Equipment("E001", "Treadmill", "High-performance treadmill", 5, "Good"));
        equipmentList.add(new Equipment("E002", "Dumbbells", "Set of dumbbells", 10, "Excellent"));
        equipmentList.add(new Equipment("E003", "Exercise Bike", "Stationary exercise bike", 3, "Fair"));
        return equipmentList;
    }

    public static void removeEquipment(String equipmentID) {
        List<Equipment> equipmentList = getAllEquipment();
        Equipment equipmentToRemove = null;
        for (Equipment equipment : equipmentList) {
            if (equipment.getEquipmentID().equals(equipmentID)) {
                equipmentToRemove = equipment;
                break;
            }
        }
        if (equipmentToRemove != null) {
            equipmentList.remove(equipmentToRemove);
            System.out.println("Equipment removed successfully.");
        } else {
            System.out.println("Equipment not found.");
        }
    }
    
}